### USER
It is used to run the commands as particular user.