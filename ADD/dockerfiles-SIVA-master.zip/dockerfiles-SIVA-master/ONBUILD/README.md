### ONBUILD

ONBUILD is used to set some hard guidelines to the image. We can control how others can use our image as their base image.