### RUN

Run instruction we use to install software, packages and other tasks. It runs at the time of image building.