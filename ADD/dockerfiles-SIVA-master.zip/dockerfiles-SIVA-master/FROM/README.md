### FROM

FROM should be the first instruction in your Dockerfile
